<?= $this->include('layout/header') ?>

<h1>About</h1>

<p>
    This Tasks for Today Management System was developed by J R.
</p>

<p>
    The system was built using CodeIgniter 4, PHP, and MySQL.
</p>

<p>
    It allows users to view today's tasks, browse the complete
    task list, and view a demo user profile.
</p>

<?= $this->include('layout/footer') ?>